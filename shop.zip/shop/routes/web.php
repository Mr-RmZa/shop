<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::prefix('admin')->middleware(['admin'])->group(function () {
    Route::get('/', [\App\Http\Controllers\Admin\AdminController::class, 'index'])->name('admin');
    Route::resource('/category', \App\Http\Controllers\Admin\CategoryController::class);
    Route::resource('/product', \App\Http\Controllers\Admin\ProductController::class);
    Route::resource('/user', \App\Http\Controllers\Admin\UserController::class);
    Route::get('/order', [\App\Http\Controllers\Admin\OrderController::class, 'index'])->name('order');
    Route::post('/order', [\App\Http\Controllers\Admin\OrderController::class, 'delete'])->name('orderDelete');
});

Route::get('/', [\App\Http\Controllers\Site\SiteController::class, 'index'])->name('index');
Route::get('/category/{menu}', [\App\Http\Controllers\Site\SiteController::class, 'menu'])->name('menu');
Route::get('/category/{menu}/{submenu}', [\App\Http\Controllers\Site\SiteController::class, 'submenu'])->name('submenu');

\Illuminate\Support\Facades\Auth::routes(['verify'=>true]);

Route::get('/reload-captcha', [\App\Http\Controllers\Site\SiteController::class, 'reloadCaptcha'])->name('reload-captcha');
Route::get('/search', [\App\Http\Controllers\Site\SiteController::class, 'search'])->name('search');
Route::post('/buy', [\App\Http\Controllers\Site\SiteController::class, 'buy'])->name('buy');
Route::get('/order', [\App\Http\Controllers\Site\SiteController::class, 'order']);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/{slug}', [\App\Http\Controllers\Site\SiteController::class, 'single'])->name('single');


