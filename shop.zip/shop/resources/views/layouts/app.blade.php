<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="/image/bg.png" type="image/jpg">
    <meta name="theme-color" content="#212529">
    <meta name="msapplication-navbutton-color" content="#212529">
    <meta name="apple-mobile-web-app-status-bar-style" content="#212529">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link href="{{url('/fonts/style.css')}}" rel="stylesheet">
    @yield('style')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    <title>@yield('title')</title>
</head>
<body class="bg-dark text-light" dir="rtl">

@yield('navbar')

<div class="container-fluid">
    <div class="row">
        @yield('content')
    </div>
</div>

<div class="container-fluid">
    @yield('site')
</div>

<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top" dir="ltr">
    <div class="col-md-4 d-flex align-items-center">
        <span class="mb-3 mb-md-0">© 2022 Mr RaMeZaNi, Inc</span>
    </div>

    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
        <li class="ms-3"><a class="text-white display-6" href="https://t.me/Mr_RmZa"><i class="bi bi-telegram"></i></a></li>
        <li class="ms-3"><a class="text-white display-6" href="https://instagram.com/Mr_RmZa"><i class="bi bi-instagram"></i></a></li>
        <li class="ms-3"><a class="text-white display-6" href="https://wa.me/989381560761"><i class="bi bi-whatsapp"></i></a></li>
    </ul>
</footer>
@yield('script')
<script>
    let prices = document.querySelectorAll(".price");

    prices.forEach((price) => {
        price.innerHTML = "تومان " + price.innerHTML.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>
</html>
