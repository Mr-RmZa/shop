@extends('layouts.app')
@section('title')
    {{$product->name}}
@endsection
@section('style')
    <meta name="description" content="{{$product->meta_description}}">
    <meta name="title" content="{{$product->meta_title}}">
    <meta name="keywords" content="{{$product->meta_keywords}}">
@endsection
@section('content')
    @include('site.navbar')
    <div class="mb-4 text-center">
        <img src="{{$product->image}}" class="img-fluid img-thumbnail" alt="{{$product->name}}">
    </div>
    <div class="text-justify">
        <h1>{{$product->name}}</h1>
        {!! $product->description !!}
        <form method="post" action="{{url('buy')}}">
            {{csrf_field()}}
            <input type="hidden" name="price" value="{{$product->price}}">
            <div class="d-grid gap-2">
                    <figure class="text-center">
                        <blockquote class="blockquote">
                            <p class="price">{{$product->price}}</p>
                        </blockquote>
                        @if(!Auth::check())
                            <figcaption class="blockquote-footer">
                                لطفا <cite title="Source Title">ثبت نام یا وارد سایت شوید</cite>
                            </figcaption>
                        @endif
                    </figure>
                <button class="btn btn-outline-success @if(!Auth::check()) disabled @endif" type="submit">پرداخت</button>
            </div>
        </form>
    </div>
@endsection
