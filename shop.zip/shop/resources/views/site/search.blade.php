@extends('layouts.app')
@section('title')
    Mr RaMeZaNi
@endsection
@section('style')
    <meta name="description" content="فروشگاه محمدحسن رمضانی محصولات فیلترشکن سرور های v2rayNG">
    <meta name="title" content="سایت فروشگاهی محمدحسن رمضانی">
    <meta name="keywords" content="محمدحسن رمضانی قریه عباس, محمدحسن رمضانی, محمدحسن, سایت فروشگاهی, فروشگاه, فیلترشکن, v2ratNG">
@endsection
@section('site')
    @include('site.navbar')
    <h1 class="text-center">عبارت جستجو شده "{{$query}}"</h1>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        @foreach($products as $product)
                <div class="col">
                    <div class="card h-100 bg-dark">
                        <a href="{{route('single', $product->slug)}}"><img src="{{$product->image}}" class="card-img-top" alt="{{$product->name}}"></a>
                        <div class="card-body">
                            <h5 class="card-title"><a class="text-decoration-none" href="{{route('single', $product->slug)}}">{{$product->name}}</a></h5>
                            {!! \Illuminate\Support\Str::limit($product->description, 100) !!}
                            <p class="price">{{$product->price}}</p>
                        </div>
                        <div class="card-footer">
                            <small>{{\Hekmatinasser\Verta\Verta::instance($product->create_at)}}</small>
                        </div>
                    </div>
                </div>
        @endforeach

    </div>

@endsection
