@extends('layouts.app')
@section('title')
    Mr RaMeZaNi
@endsection
@section('style')
    <meta name="description" content="فروشگاه محمدحسن رمضانی محصولات فیلترشکن سرور های v2rayNG">
    <meta name="title" content="سایت فروشگاهی محمدحسن رمضانی">
    <meta name="keywords" content="محمدحسن رمضانی قریه عباس, محمدحسن رمضانی, محمدحسن, سایت فروشگاهی, فروشگاه, فیلترشکن, v2ratNG">
@endsection
@section('content')
    @include('site.navbar')
    @if($msg === 'پرداخت با موفقیت انجام شد.')
        <div class="alert alert-success" role="alert">
            {{$msg}}
        </div>
    @else
        <div class="alert alert-danger" role="alert">
            {{$msg}}
        </div>
    @endif
@endsection
