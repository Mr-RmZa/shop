@extends('layouts.app')
@section('title')
    Mr RaMeZaNi
@endsection
@section('style')
    <meta name="description" content="فروشگاه محمدحسن رمضانی محصولات فیلترشکن سرور های v2rayNG">
    <meta name="title" content="سایت فروشگاهی محمدحسن رمضانی">
    <meta name="keywords" content="محمدحسن رمضانی قریه عباس, محمدحسن رمضانی, محمدحسن, سایت فروشگاهی, فروشگاه, فیلترشکن, v2ratNG">
@endsection
@section('site')
<div class="row">
    @include('site.navbar')
    <div class="col-12 col-sm-6">
        <img src="/image/bg.png" class="img-fluid rounded float-end">
    </div>
    <div class="col-12 col-sm-6 mt-5 text-center">
        <h1>محمدحسن رمضانی</h1>
        <p class="text-justify">
            محمدحسن رمضانی قریه عباس در 4 تیر سال 1384 یعنی در 1384/4/4 در مشهد ایران به دنیا آمد.
            وی فرزند کوچک یک خانواده 4 نفره بود. پدر او سهراب رمضانی متولد مشهد و بزرگ شده مشهد، کارگر و مادر او نیز متولد مشهد وی به نام معصومه دشتگی و خانه دار بود. او یک برادر بزرگ تر به نام محمدحسین رمضانی متولد 1383 که یک سال و چهار ماه از او بزرگ تر بود دارد.
            محمدحسن دوران کودکی خود را در مشهد سپری کرد. در سن 10 سالگی اولین رایانه شخصی خود را خرید. محمدحسن در 15 سالگی وقتی تعیین رشته کرد و به رشته کامپیوتر رفت علاقه مند به برنامه نویسی شد و شروع به یادگیری کرد...
        </p>
        <a href="#products" class="btn btn-outline-secondary mb-5">مشاهده محصولات <i class="bi bi-caret-down-fill"></i></a>
    </div>
</div>

<div class="row row-cols-1 row-cols-md-3 g-4 border-top">
    @foreach($products as $product)
        <div class="col" id="products">
            <div class="card h-100 bg-dark">
                <a href="{{route('single', $product->slug)}}"><img src="{{$product->image}}" class="card-img-top" alt="{{$product->name}}"></a>
                <div class="card-body">
                    <h5 class="card-title"><a class="text-decoration-none" href="{{route('single', $product->slug)}}">{{$product->name}}</a></h5>
                    {!! \Illuminate\Support\Str::limit($product->description, 100) !!}
                    <p class="price">{{$product->price}}</p>
                </div>
                <div class="card-footer">
                    <small>{{\Hekmatinasser\Verta\Verta::instance($product->create_at)}}</small>
                </div>
            </div>
        </div>
    @endforeach
</div>
@endsection
