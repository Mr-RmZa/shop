@extends('layouts.app')

@section('content')
    <form method="post" action="{{route('category.store')}}" enctype="multipart/form-data">

        {{csrf_field()}}

        @include('admin.partials.form-errors')

        <div class="mb-3">
            <label for="name" class="form-label">name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <select class="form-select" aria-label="Default select example" name="parent_id">
            <option value="0" selected>دسته بندی اصلی انتخاب کنید</option>
            @foreach($categories as $key=>$value)
                <option value="{{$key}}">{{$value}}</option>
            @endforeach
        </select>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-outline-success">Success</button>
        </div>
    </form>
@endsection
