@extends('layouts.app')

@section('content')
    <a href="{{route('category.create')}}" class="btn btn-success">ایجاد دسته بندی جدید</a>
    <table class="table table-dark table-striped table-hover table-borderless table-sm table-responsive">
        <thead>
        <tr class="text-center">
            <td>نام دسته بندی</td>
            <td>دسته اصلی</td>
            <td>عملیات</td>
        </tr>
        </thead>
        <tbody>
        @foreach($categories as $category)
            <tr class="text-center">
                <td>{{$category->name}}</td>
                <td>{{$category->getParent->name}}</td>
                <td>
                    <a href="{{route('category.edit', $category->id)}}" class="btn btn-warning">ویرایش</a>
                    <form action="{{route('category.destroy', $category->id)}}" method="post">
                        @csrf
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger"> حذف</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
