@extends('layouts.app')

@section('content')
    <div class="col">
        <h1 class="text-center">پنل مدیریت</h1>
    </div>

    <ul class="list-group">
        <li class="list-group-item">
            <a class="text-decoration-none" href="{{route('category.index')}}">نمایش دسته بندی ها</a>
        </li>

        <li class="list-group-item">
            <a class="text-decoration-none" href="{{route('product.index')}}">نمایش محصولات</a>
        </li>

        <li class="list-group-item">
            <a class="text-decoration-none" href="{{route('user.index')}}">نمایش کاربر ها</a>
        </li>

        <li class="list-group-item">
            <a class="text-decoration-none" href="{{route('order')}}">نمایش سفارش ها</a>
        </li>
    </ul>
@endsection
