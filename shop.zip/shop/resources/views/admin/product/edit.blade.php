@extends('layouts.app')

@section('content')
    <form method="post" action="{{route('product.update', $product->id)}}" enctype="multipart/form-data">

        {{csrf_field()}}

        {{method_field('PATCH')}}

        @include('admin.partials.form-errors')

        <div class="mb-3">
            <label for="name" class="form-label">title</label>
            <input type="text" class="form-control" id="name" name="name" value="{{$product->name}}">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">price</label>
            <input type="number" class="form-control" id="price" name="price" value="{{$product->price}}">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">description</label>
            <textarea class="form-control ckeditor" id="description" rows="3" name="description">{{$product->description}}</textarea>
        </div>

        <select class="form-select" multiple aria-label="multiple select example" name="category_id[]">
            <option value="0">دسته بندی انتخاب کنید</option>
            @foreach($categories as $category)
                <option
                    @foreach($product->categories as $cat)
                    @if($cat->id===$category->id) selected @endif
                    @endforeach
                    value="{{$category->id}}">{{$category->name}}</option>
            @endforeach
        </select>

        <div class="mb-3">
            <label for="image" class="form-label">image</label>
            <input class="form-control" type="file" id="image" name="image">
            <img src="{{$product->image}}" class="img-thumbnail" width="100">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">meta_description</label>
            <input type="text" class="form-control" id="meta_description" name="meta_description" value="{{$product->meta_description}}">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">meta_title</label>
            <input type="text" class="form-control" id="meta_title" name="meta_title" {{$product->meta_title}}>
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">meta_keywords</label>
            <input type="text" class="form-control" id="meta_keywords" name="meta_keywords" {{$product->meta_keywords}}>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-outline-success">Success</button>
        </div>
    </form>
@endsection

@section('script')
    <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.ckeditor').ckeditor();
        });
    </script>
@endsection
