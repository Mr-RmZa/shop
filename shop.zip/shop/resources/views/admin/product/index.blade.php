@extends('layouts.app')
@section('content')
    <a href="{{route('product.create')}}" class="btn btn-success">ایجاد محصول جدید</a>
            <table class="table table-dark table-striped table-hover table-borderless table-sm table-responsive">
                <thead>
                    <tr class="text-center">
                        <td>نام محصول</td>
                        <td>قیمت محصول</td>
                        <td>توضیحات</td>
                        <td>تصویر محصول</td>
                        <td>دسته بندی</td>
                        <td>عملیات</td>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $product)
                        <tr class="text-center">
                            <td>{{$product->name}}</td>
                            <td>{{$product->price}}</td>
                            <td>{!! \Illuminate\Support\Str::limit($product->description, 50) !!}</td>
                            <td><img src="{{$product->image}}" width="100"></td>
                                <td>
                                    @foreach ($product->categories()->pluck('name') as $category)
                                    {{$category}}</br>
                                    @endforeach
                                </td>
                            <td>
                                <a href="{{route('product.edit', $product->id)}}" class="btn btn-warning">ویرایش</a>
                                <form action="{{route('product.destroy', $product->id)}}" method="post">
                                    @csrf
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger"> حذف</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
@endsection
