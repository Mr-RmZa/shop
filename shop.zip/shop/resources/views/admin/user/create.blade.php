@extends('layouts.app')

@section('content')
    <form method="post" action="{{route('user.store')}}">

        {{csrf_field()}}

        @include('admin.partials.form-errors')

        <div class="mb-3">
            <label for="name" class="form-label">name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <select class="form-select" multiple aria-label="multiple select example" name="role_id[]" required>
            <option value="0">سطح دسترسی انتخاب کنید</option>
            @foreach($roles as $key=>$value)
                <option value="{{$key}}">{{$value}}</option>
            @endforeach
        </select>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-outline-success">Success</button>
        </div>
    </form>
@endsection
