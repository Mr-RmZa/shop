@extends('layouts.app')

@section('content')
    <a href="{{route('user.create')}}" class="btn btn-success">ایجاد کاربر جدید</a>
    <table class="table table-dark table-striped table-hover table-borderless table-sm table-responsive">
        <thead>
        <tr class="text-center">
            <td>نام</td>
            <td>ایمیل</td>
            <td>سطح دسترسی</td>
            <td>عملیات</td>
        </tr>
        </thead>
        <tbody>
        @foreach($users as $user)
            <tr class="text-center">
                <td>{{$user->name}}</td>
                <td>{{$user->email}}</td>
                <td>
                    @foreach($user->roles as $role)
                        {{$role->name}}
                    @endforeach
                </td>
                <td>
                    <a href="{{route('user.edit', $user->id)}}" class="btn btn-warning">ویرایش</a>
                    <form action="{{route('user.destroy', $user->id)}}" method="post">
                        @csrf
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger"> حذف</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
