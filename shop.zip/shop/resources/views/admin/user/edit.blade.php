@extends('layouts.app')

@section('content')
    <form method="post" action="{{route('user.update', $user->id)}}" enctype="multipart/form-data">

        {{csrf_field()}}

        {{method_field('PATCH')}}

        @include('admin.partials.form-errors')

        <div class="mb-3">
            <label for="name" class="form-label">name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{$user->name}}">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">email</label>
            <input type="text" class="form-control" id="email" name="email" value="{{$user->email}}">
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">password</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>

        <select class="form-select" multiple aria-label="multiple select example" name="role_id[]">
            <option value="0">سطح دسترسی انتخاب کنید</option>
            @foreach($roles as $role)
                <option
                    @foreach($role->users as $users)
                    @if($users->id===$user->id) selected @endif
                    @endforeach
                    value="{{$role->id}}">{{$role->name}}</option>
            @endforeach
        </select>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-outline-success">Success</button>
        </div>
    </form>
@endsection
