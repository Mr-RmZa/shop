@extends('layouts.app')

@section('content')
    <table class="table table-dark table-striped table-hover table-borderless table-sm table-responsive">
        <thead>
        <tr class="text-center">
            <td>قیمت</td>
            <td>شناسه کاربر</td>
            <td>ایمیل کاربر</td>
            <td>شماره کاربر</td>
            <td>شناسه</td>
            <td>وضعیت</td>
            <td>عملیات</td>
        </tr>
        </thead>
        <tbody>
        @foreach($orders as $order)
            <tr class="text-center">
                <td>{{$order->price}}</td>
                <td>{{$order->user_id}}</td>
                <td>{{$order->email}}</td>
                <td>{{$order->phone}}</td>
                <td>{{$order->authority}}</td>
                <td>
                    @if($order->status === 0)
                        <span class="badge bg-danger">پرداخت نشده</span>
                    @else
                        <span class="badge bg-success">پرداخت شده</span>
                    @endif
                </td>
                <td>
                    <form action="{{route('orderDelete')}}" method="post">
                        @csrf
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger"> حذف</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
