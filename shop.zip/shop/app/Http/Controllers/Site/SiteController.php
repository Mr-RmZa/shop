<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\lib\zarinpal;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SiteController extends Controller
{
    public function index()
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $products = Product::latest()->orderBy('id', 'DESC')->limit(3)->get();
        return view('site.index', compact(['menus', 'products']));
    }

    public function menu($id)
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $categoryProducts = Category::with('products')->whereId($id)->get();
        return view('site.menu', compact(['menus', 'categoryProducts']));
    }

    public function submenu($id, $subid)
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $categoryProducts = Category::with('products')->whereId($subid)->get();
        return view('site.submenu', compact(['menus', 'categoryProducts']));
    }

    public function search(Request $request)
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $query = $request->input('search');
        $products = Product::where('name', 'Like', '%'.$query.'%')->paginate(3);
        return view('site.search', compact(['menus', 'products', 'query']));
    }

    public function single($slug)
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $product = Product::where('slug', $slug)->first();
        return view('site.single', compact(['menus', 'product']));
    }

    public function reloadCaptcha()
    {
        return response()->json(['captcha'=> captcha_img()]);
    }

    public function buy(Request $request)
    {
        $buy = new zarinpal();
        $res = $buy->pay($request->price,Auth::user()->email,Auth::user()->phone);
        $order = new Order();
        $order->price = $request->price;
        $order->user_id = Auth::user()->id;
        $order->email = Auth::user()->email;
        $order->phone = Auth::user()->phone;
        $order->authority = $res;
        $order->save();
        return redirect('https://www.zarinpal.com/pg/StartPay/' . $res);
    }

    public function order(Request $request)
    {
        $menus = Category::with('getChild')->where('parent_id', 0)->get();
        $MerchantID = '17b885b3-530a-4164-8311-887627e4db4f';
        $Authority = $request->get('Authority') ;
        //ما در اینجا مبلغ مورد نظر را بصورت دستی نوشتیم اما در پروژه های واقعی باید از دیتابیس بخوانیم
        $order = Order::where('authority', $Authority)->first();
        $Amount = $order->price;
        if ($request->get('Status') == 'OK') {
            $client = new \nusoap_client('https://www.zarinpal.com/pg/services/WebGate/wsdl', 'wsdl');
            $client->soap_defencoding = 'UTF-8';
            //در خط زیر یک درخواست به زرین پال ارسال می کنیم تا از صحت پرداخت کاربر مطمئن شویم
            $result = $client->call('PaymentVerification', [
                [
                    //این مقادیر را به سایت زرین پال برای دریافت تاییدیه نهایی ارسال می کنیم
                    'MerchantID'     => $MerchantID,
                    'Authority'      => $Authority,
                    'Amount'         => $Amount,
                ],
            ]);
            if ($result['Status'] == 100) {
                $order->status = 1;
                $order->save();
                $msg = 'پرداخت با موفقیت انجام شد به زودی به شما ارتباط برقرار می کینم';

            } else {
                $msg = 'خطا در انجام عملیات';
            }
        }
        else
        {
            $msg = 'خطا در انجام عملیات';
        }
        return view('site.order', compact(['msg', 'menus']));
    }
}
